import re

from .constants import TYPE_NMEA_0183
from .exceptions import (
    InvalidCarriageReturn, 
    InvalidNmeaType, 
    InvalidSentenceStructure, 
    InvalidChecksum,
    InvalidNmeaSentence
)
from .utils import calculate_checksum


def validate_nmea_sentence(
    data: str, 
    nmea_type: str = TYPE_NMEA_0183, 
    carriage_return: bool = False
) -> bool:
    if carriage_return:
        if not data.endswith("\r\n"):
            raise InvalidCarriageReturn(
                "NMEA data didn't end with carriage return", 
                sentence=data
            )
        data = data[:-2]  # Remove carriage return
    
    if nmea_type != TYPE_NMEA_0183:
        raise InvalidNmeaType(
            f"No support for NMEA type: {nmea_type}", 
            sentence=data
        )
    
    return validate_sentence(data)
    
def validate_sentence(line: str) -> bool:
    """Validate NMEA sentence format"""
    if not line or line[0] not in ("$", "!"):
        raise InvalidNmeaSentence(
            "Sentence must start with '$' or '!'", 
            sentence=line
        )
    
    if len(line) > 82:
        raise InvalidSentenceStructure(
            "Sentence exceeds 82 character limit", 
            sentence=line
        )
    
    if "*" not in line:
        raise InvalidSentenceStructure(
            "Sentence must contain checksum (*)", 
            sentence=line
        )
    
    return validate_checksum(line)

def validate_checksum(sentence: str) -> bool:
    """Validate NMEA checksum"""
    try:
        raw_data, checksum = sentence.split('*')
    except ValueError:
        star_count = sentence.count('*')
        raise InvalidSentenceStructure(
            f"Expected '*' once, but found {star_count}", 
            sentence=sentence
        )
    
    raw_data = raw_data.lstrip('$')
    calculated = calculate_checksum(raw_data)
    if checksum.upper() != calculated:
        raise InvalidChecksum(
            f"Checksum mismatch: expected {calculated}, got {checksum}", 
            sentence=sentence
        )
    
    return True
