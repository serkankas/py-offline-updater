from typing import Optional, Dict, List, Set

from . import nmea_sentence_types as NST
from .validators import validate_sentence
from .utils import extract_sender, extract_sentence_type
from .parsers import SENTENCE_PARSERS_MAP

class NmeaParser:
    """NMEA 0183 parser with selective sentence filtering"""
    def __init__(self, allowed_sentences: Optional[List[str]] = None):
        """
        Args:
            allowed_sentences: List of sentence types or None for all
                             Örnek: [NST.HDT, NST.GGA]
        """
        if allowed_sentences is not None:
            self.allowed_sentences: Set[str] = set(allowed_sentences)
        else:
            self.allowed_sentences: Set[str] = NST.ALL_SENTENCES
        
        self._validate_allowed_sentences()
    
    def _validate_allowed_sentences(self):
        unsupported = self.allowed_sentences - NST.ALL_SENTENCES
        if unsupported:
            raise ValueError(f"Unsupported sentence types: {unsupported}")

    def parse(self, sentence: str, validate: bool = True, include_talker=False) -> Dict:
        result = {"error": {}, "data": {}, "metadata": {}}  # ← metadata eklendi
        
        try:
            if validate:
                validate_sentence(sentence)
            
            sentence_type = extract_sentence_type(sentence, include_talker)
            sender = extract_sender(sentence)
            
            result["metadata"] = {
                "talker_id": sender,
                "sentence_type": sentence_type,
                "full_sentence": f"{sender}{sentence_type}",
                "raw": sentence
            }
            
            if sentence_type not in self.allowed_sentences:
                result["error"]["message"] = f"Sentence type '{sentence_type}' not allowed"
                return result
            
            parser_class = SENTENCE_PARSERS_MAP.get(sentence_type)
            if not parser_class:
                result["error"]["message"] = f"No parser for sentence type: {sentence_type}"
                return result
            
            data_part = sentence.split(',', 1)[1].split('*')[0]
            
            parsed = parser_class.parse(data_part)
            result["error"] = parsed.get("error", {})
            result["data"] = parsed.get("data", {})
            
        except Exception as e:
            result["error"]["message"] = f"Parse error: {str(e)}"
        
        return result
