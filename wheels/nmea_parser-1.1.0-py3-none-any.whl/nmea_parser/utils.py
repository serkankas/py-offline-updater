def calculate_checksum(nmea_message: str) -> str:
    checksum = 0
    for char in nmea_message:
        checksum ^= ord(char)
    
    hex_value = hex(checksum)[2:].upper()
    return hex_value.zfill(2)


def extract_sentence_type(sentence: str, include_talker: bool = False) -> str:
    """
    Extract sentence type from NMEA sentence
    
    Args:
        sentence: NMEA sentence string
        include_talker: If True, return full header (e.g., PPLAR, GPHDT)
                       If False, return last 3 chars (e.g., LAR, HDT)
    """
    clean = sentence.lstrip('$').split('*')[0]
    header = clean.split(',')[0]
    
    if include_talker:
        return header.upper()  # Full header (PPLAR, GPHDT, vb.)
    else:
        return header[-3:].upper()  # Last 3 chars (LAR, HDT, vb.)


def extract_sender(sentence: str) -> str:
    clean = sentence.lstrip('$').split('*')[0]
    header = clean.split(',')[0]
    sender = header[:-3] if len(header) >= 3 else header
    return sender.upper()

