from typing import Dict
from .base import BaseSentenceParser


class TRDParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 4:
            result["error"]["message"] = f"TRD length mismatch: expected 4, got {len(fields)}"
            return result
        
        try:
            result["data"]["thruster_id"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["direction"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["power"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["status"] = fields[3].strip() if fields[3].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid TRD field: {str(e)}"
        
        return result