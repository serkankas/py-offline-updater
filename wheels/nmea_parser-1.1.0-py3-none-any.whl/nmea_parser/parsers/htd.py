from typing import Dict
from .base import BaseSentenceParser


class HTDParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 5:
            result["error"]["message"] = f"HTD length mismatch: expected 5, got {len(fields)}"
            return result
        
        try:
            result["data"]["override"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["rudder_direction"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["rudder_angle"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["selected_heading"] = float(fields[3].strip()) if fields[3].strip() else None
            result["data"]["rudder_limit"] = float(fields[4].strip()) if fields[4].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid HTD field: {str(e)}"
        
        return result