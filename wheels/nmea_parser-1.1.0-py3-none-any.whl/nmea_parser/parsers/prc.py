from typing import Dict
from .base import BaseSentenceParser


class PRCParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 2:
            result["error"]["message"] = f"PRC length mismatch: expected min 2, got {len(fields)}"
            return result
        
        try:
            result["data"]["engine_id"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["rpm_order"] = float(fields[1].strip()) if fields[1].strip() else None
            
            if len(fields) > 2:
                result["data"]["pitch_order"] = float(fields[2].strip()) if fields[2].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid PRC field: {str(e)}"
        
        return result