from typing import Dict
from .base import BaseSentenceParser


class HRMParser(BaseSentenceParser):
    """
    HRM (Heading Roll Pitch) Parser
    
    Note: This is a non-standard NMEA sentence used by some marine equipment
    manufacturers (e.g., Kongsberg). The format and field definitions may vary
    between different manufacturers. This implementation is based on the Consilium
    HRM specification.
    """
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 6:
            result["error"]["message"] = f"HRM length mismatch: expected min 6, got {len(fields)}"
            return result
        
        try:
            result["data"]["hrm_type"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["roll_angle"] = float(fields[1].strip()) if fields[1].strip() else None
            result["data"]["status"] = fields[5].strip() if fields[5].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid HRM field: {str(e)}"
        
        return result