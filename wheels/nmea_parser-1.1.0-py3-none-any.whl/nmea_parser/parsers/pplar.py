from typing import Dict
from .base import BaseSentenceParser


class PPLARParser(BaseSentenceParser):
    """
    PPLAR (Proprietary Sentence - Roll and Pitch) Parser
    
    Note: This is a proprietary NMEA sentence format. The exact format and
    interpretation may vary depending on the manufacturer. This implementation
    is based on standard roll and pitch sensor specifications.
    """
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 2:
            result["error"]["message"] = f"PPLAR length mismatch: expected 2, got {len(fields)}"
            return result
        
        try:
            result["data"]["roll"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["pitch"] = float(fields[1].strip()) if fields[1].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid PPLAR field: {str(e)}"
        
        return result