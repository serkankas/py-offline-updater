from typing import Dict

class BaseSentenceParser:
    """Base class for all sentence parsers"""
    
    @staticmethod
    def parse(data: str) -> Dict:
        raise NotImplementedError