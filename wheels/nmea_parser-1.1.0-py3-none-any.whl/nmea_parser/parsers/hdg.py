from typing import Dict
from .base import BaseSentenceParser


class HDGParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 5:
            result["error"]["message"] = f"HDG length mismatch: expected 5, got {len(fields)}"
            return result
        
        try:
            result["data"]["heading_magnetic"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["magnetic_deviation"] = float(fields[1].strip()) if fields[1].strip() else None
            result["data"]["deviation_direction"] = fields[2].strip() if fields[2].strip() else None
            result["data"]["magnetic_variation"] = float(fields[3].strip()) if fields[3].strip() else None
            result["data"]["variation_direction"] = fields[4].strip() if fields[4].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid HDG field: {str(e)}"
        
        return result