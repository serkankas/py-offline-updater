from typing import Dict
from .base import BaseSentenceParser


class MWDParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 8:
            result["error"]["message"] = f"MWD length mismatch: expected 8, got {len(fields)}"
            return result
        
        try:
            result["data"]["wind_direction_true"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["true_reference"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["wind_direction_magnetic"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["magnetic_reference"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["wind_speed_1"] = float(fields[4].strip()) if fields[4].strip() else None
            result["data"]["wind_speed_units_1"] = fields[5].strip() if fields[5].strip() else None
            result["data"]["wind_speed_2"] = float(fields[6].strip()) if fields[6].strip() else None
            result["data"]["wind_speed_units_2"] = fields[7].strip() if fields[7].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid MWD field: {str(e)}"
        
        return result