from typing import Dict
from .base import BaseSentenceParser

class HDTParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')

        if len(fields) != 2:
            result["error"]["message"] = f"HDT length mismatch: expected 2, got {len(fields)}"
            return result

        try:
            heading = fields[0].strip()
            result["data"]["heading_degrees"] = float(heading) if heading else None
            result["data"]["true_indicator"] = fields[1].strip()  # "T"
        except ValueError:
            result["error"]["message"] = f"Invalid heading value: {fields[0]}"

        return result
