from typing import Dict
from .base import BaseSentenceParser


class RMCParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 9:
            result["error"]["message"] = f"RMC length mismatch: expected min 9, got {len(fields)}"
            return result
        
        try:
            result["data"]["utc_time"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["status"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["latitude"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["latitude_direction"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["longitude"] = float(fields[4].strip()) if fields[4].strip() else None
            result["data"]["longitude_direction"] = fields[5].strip() if fields[5].strip() else None
            result["data"]["speed_knots"] = float(fields[6].strip()) if fields[6].strip() else None
            result["data"]["track_angle"] = float(fields[7].strip()) if fields[7].strip() else None
            result["data"]["date"] = fields[8].strip() if fields[8].strip() else None
            
            if len(fields) > 9:
                result["data"]["magnetic_variation"] = float(fields[9].strip()) if fields[9].strip() else None
            if len(fields) > 10:
                result["data"]["mag_var_direction"] = fields[10].strip() if fields[10].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid RMC field: {str(e)}"
        
        return result