from typing import Dict
from .base import BaseSentenceParser


class GLLParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 6:
            result["error"]["message"] = f"GLL length mismatch: expected min 6, got {len(fields)}"
            return result
        
        try:
            result["data"]["latitude"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["latitude_direction"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["longitude"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["longitude_direction"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["utc_time"] = fields[4].strip() if fields[4].strip() else None
            result["data"]["status"] = fields[5].strip() if fields[5].strip() else None
            
            if len(fields) > 6:
                result["data"]["mode_indicator"] = fields[6].strip() if fields[6].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid GLL field: {str(e)}"
        
        return result