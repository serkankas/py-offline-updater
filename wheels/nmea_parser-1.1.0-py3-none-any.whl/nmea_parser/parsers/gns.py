from typing import Dict
from .base import BaseSentenceParser


class GNSParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 12:
            result["error"]["message"] = f"GNS length mismatch: expected min 12, got {len(fields)}"
            return result
        
        try:
            result["data"]["utc_time"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["latitude"] = float(fields[1].strip()) if fields[1].strip() else None
            result["data"]["latitude_direction"] = fields[2].strip() if fields[2].strip() else None
            result["data"]["longitude"] = float(fields[3].strip()) if fields[3].strip() else None
            result["data"]["longitude_direction"] = fields[4].strip() if fields[4].strip() else None
            result["data"]["mode_indicator"] = fields[5].strip() if fields[5].strip() else None
            result["data"]["num_satellites"] = int(fields[6].strip()) if fields[6].strip() else None
            result["data"]["hdop"] = float(fields[7].strip()) if fields[7].strip() else None
            result["data"]["orthometric_height"] = float(fields[8].strip()) if fields[8].strip() else None
            result["data"]["geoid_separation"] = float(fields[9].strip()) if fields[9].strip() else None
            
            if len(fields) > 10:
                result["data"]["age_of_differential"] = float(fields[10].strip()) if fields[10].strip() else None
            if len(fields) > 11:
                result["data"]["reference_station_id"] = fields[11].strip() if fields[11].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid GNS field: {str(e)}"
        
        return result