from typing import Dict
from .base import BaseSentenceParser


class VTGParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) < 8:
            result["error"]["message"] = f"VTG length mismatch: expected min 8, got {len(fields)}"
            return result
        
        try:
            result["data"]["track_true"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["true_indicator"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["track_magnetic"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["magnetic_indicator"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["speed_knots"] = float(fields[4].strip()) if fields[4].strip() else None
            result["data"]["knots_indicator"] = fields[5].strip() if fields[5].strip() else None
            result["data"]["speed_kph"] = float(fields[6].strip()) if fields[6].strip() else None
            result["data"]["kph_indicator"] = fields[7].strip() if fields[7].strip() else None
            
            if len(fields) > 8:
                result["data"]["mode_indicator"] = fields[8].strip() if fields[8].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid VTG field: {str(e)}"
        
        return result