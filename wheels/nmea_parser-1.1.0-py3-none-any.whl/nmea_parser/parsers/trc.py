from typing import Dict
from .base import BaseSentenceParser


class TRCParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 3:
            result["error"]["message"] = f"TRC length mismatch: expected 3, got {len(fields)}"
            return result
        
        try:
            result["data"]["thruster_id"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["direction"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["power"] = float(fields[2].strip()) if fields[2].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid TRC field: {str(e)}"
        
        return result