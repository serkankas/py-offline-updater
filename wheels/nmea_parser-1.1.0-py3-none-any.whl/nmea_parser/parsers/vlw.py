from typing import Dict
from .base import BaseSentenceParser


class VLWParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if not (4 <= len(fields) <= 8):
            result["error"]["message"] = f"VLW length mismatch: expected 4-8, got {len(fields)}"
            return result
        
        try:
            result["data"]["total_water_distance"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["water_distance_unit"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["water_distance_since_reset"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["reset_distance_unit"] = fields[3].strip() if fields[3].strip() else None
            
            if len(fields) > 4:
                result["data"]["total_ground_distance"] = float(fields[4].strip()) if fields[4].strip() else None
            if len(fields) > 5:
                result["data"]["ground_distance_unit"] = fields[5].strip() if fields[5].strip() else None
            if len(fields) > 6:
                result["data"]["ground_distance_since_reset"] = float(fields[6].strip()) if fields[6].strip() else None
            if len(fields) > 7:
                result["data"]["ground_reset_unit"] = fields[7].strip() if fields[7].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid VLW field: {str(e)}"
        
        return result