from typing import Dict
from .base import BaseSentenceParser


class VBWParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 6:
            result["error"]["message"] = f"VBW length mismatch: expected 6, got {len(fields)}"
            return result
        
        try:
            result["data"]["longitudinal_water_speed"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["transverse_water_speed"] = float(fields[1].strip()) if fields[1].strip() else None
            result["data"]["water_speed_valid"] = fields[2].strip() if fields[2].strip() else None
            result["data"]["longitudinal_ground_speed"] = float(fields[3].strip()) if fields[3].strip() else None
            result["data"]["transverse_ground_speed"] = float(fields[4].strip()) if fields[4].strip() else None
            result["data"]["ground_speed_valid"] = fields[5].strip() if fields[5].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid VBW field: {str(e)}"
        
        return result