from typing import Dict
from .base import BaseSentenceParser


class ZDAParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 6:
            result["error"]["message"] = f"ZDA length mismatch: expected 6, got {len(fields)}"
            return result
        
        try:
            result["data"]["utc_time"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["day"] = int(fields[1].strip()) if fields[1].strip() else None
            result["data"]["month"] = int(fields[2].strip()) if fields[2].strip() else None
            result["data"]["year"] = int(fields[3].strip()) if fields[3].strip() else None
            result["data"]["local_zone_hour"] = int(fields[4].strip()) if fields[4].strip() else None
            result["data"]["local_zone_minute"] = int(fields[5].strip()) if fields[5].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid ZDA field: {str(e)}"
        
        return result