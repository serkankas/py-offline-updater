from typing import Dict
from .base import BaseSentenceParser


class RPMParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 5:
            result["error"]["message"] = f"RPM length mismatch: expected 5, got {len(fields)}"
            return result
        
        try:
            result["data"]["source"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["engine_number"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["rpm"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["propeller_pitch"] = float(fields[3].strip()) if fields[3].strip() else None
            result["data"]["status"] = fields[4].strip() if fields[4].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid RPM field: {str(e)}"
        
        return result