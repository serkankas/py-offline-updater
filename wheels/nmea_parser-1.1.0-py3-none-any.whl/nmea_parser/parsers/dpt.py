from typing import Dict
from .base import BaseSentenceParser


class DPTParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if not (2 <= len(fields) <= 3):
            result["error"]["message"] = f"DPT length mismatch: expected 2-3, got {len(fields)}"
            return result
        
        try:
            result["data"]["water_depth"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["transducer_offset"] = float(fields[1].strip()) if fields[1].strip() else None
            
            if len(fields) == 3:
                result["data"]["max_range_scale"] = float(fields[2].strip()) if fields[2].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid DPT field: {str(e)}"
        
        return result