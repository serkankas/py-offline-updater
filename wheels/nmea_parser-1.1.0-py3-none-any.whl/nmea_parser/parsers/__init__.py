from .hdt import HDTParser
from .zda import ZDAParser
from .gga import GGAParser
from .gns import GNSParser
from .gll import GLLParser
from .rmc import RMCParser
from .dtm import DTMParser
from .vbw import VBWParser
from .vhw import VHWParser
from .vtg import VTGParser
from .ths import THSParser
from .hdg import HDGParser
from .rot import ROTParser
from .dpt import DPTParser
from .mwv import MWVParser
from .mwd import MWDParser
from .vlw import VLWParser
from .hrm import HRMParser
from .pplar import PPLARParser
from .hss import HSSParser
from .ror import RORParser
from .htc import HTCParser
from .htd import HTDParser
from .rrs import RRSParser
from .rsa import RSAParser
from .prc import PRCParser
from .rpm import RPMParser
from .trc import TRCParser
from .trd import TRDParser

SENTENCE_PARSERS_MAP = {
    'HDT': HDTParser,
    'ZDA': ZDAParser,
    'GGA': GGAParser,
    'GNS': GNSParser,
    'GLL': GLLParser,
    'RMC': RMCParser,
    'DTM': DTMParser,
    'VBW': VBWParser,
    'VHW': VHWParser,
    'VTG': VTGParser,
    'THS': THSParser,
    'HDG': HDGParser,
    'ROT': ROTParser,
    'DPT': DPTParser,
    'MWV': MWVParser,
    'MWD': MWDParser,
    'VLW': VLWParser,
    'HRM': HRMParser,
    'PPLAR': PPLARParser,
    'HSS': HSSParser,
    'ROR': RORParser,
    'HTC': HTCParser,
    'HTD': HTDParser,
    'RRS': RRSParser,
    'RSA': RSAParser,
    'PRC': PRCParser,
    'RPM': RPMParser,
    'TRC': TRCParser,
    'TRD': TRDParser,
}
