from typing import Dict
from .base import BaseSentenceParser


class MWVParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 5:
            result["error"]["message"] = f"MWV length mismatch: expected 5, got {len(fields)}"
            return result
        
        try:
            result["data"]["wind_angle"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["wind_reference"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["wind_speed"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["wind_speed_units"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["status"] = fields[4].strip() if fields[4].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid MWV field: {str(e)}"
        
        return result