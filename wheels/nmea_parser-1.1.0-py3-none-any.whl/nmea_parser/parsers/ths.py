from typing import Dict
from .base import BaseSentenceParser


class THSParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 2:
            result["error"]["message"] = f"THS length mismatch: expected 2, got {len(fields)}"
            return result
        
        try:
            result["data"]["heading"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["mode"] = fields[1].strip() if fields[1].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid THS field: {str(e)}"
        
        return result