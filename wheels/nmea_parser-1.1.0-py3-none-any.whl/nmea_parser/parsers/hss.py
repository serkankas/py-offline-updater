from typing import Dict
from .base import BaseSentenceParser


class HSSParser(BaseSentenceParser):
    """
    HSS (Hull Stress Sentence) Parser
    
    Note: This is a proprietary NMEA sentence used for monitoring hull stress
    in marine vessels. The format may vary between manufacturers.
    """
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 5:
            result["error"]["message"] = f"HSS length mismatch: expected 5, got {len(fields)}"
            return result
        
        try:
            result["data"]["hull_stress"] = float(fields[2].strip()) if fields[2].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid HSS field: {str(e)}"
        
        return result