from typing import Dict
from .base import BaseSentenceParser


class RSAParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 4:
            result["error"]["message"] = f"RSA length mismatch: expected 4, got {len(fields)}"
            return result
        
        try:
            result["data"]["starboard_angle"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["starboard_status"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["port_angle"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["port_status"] = fields[3].strip() if fields[3].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid RSA field: {str(e)}"
        
        return result