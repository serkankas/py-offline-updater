from typing import Dict
from .base import BaseSentenceParser


class ROTParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 2:
            result["error"]["message"] = f"ROT length mismatch: expected 2, got {len(fields)}"
            return result
        
        try:
            result["data"]["rate_of_turn"] = float(fields[0].strip()) if fields[0].strip() else None
            result["data"]["status"] = fields[1].strip() if fields[1].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid ROT field: {str(e)}"
        
        return result