from typing import Dict
from .base import BaseSentenceParser


class DTMParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 8:
            result["error"]["message"] = f"DTM length mismatch: expected 8, got {len(fields)}"
            return result
        
        try:
            result["data"]["local_datum_code"] = fields[0].strip() if fields[0].strip() else None
            result["data"]["datum_subdivision"] = fields[1].strip() if fields[1].strip() else None
            result["data"]["lat_offset_minutes"] = float(fields[2].strip()) if fields[2].strip() else None
            result["data"]["lat_offset_direction"] = fields[3].strip() if fields[3].strip() else None
            result["data"]["long_offset_minutes"] = float(fields[4].strip()) if fields[4].strip() else None
            result["data"]["long_offset_direction"] = fields[5].strip() if fields[5].strip() else None
            result["data"]["altitude_offset"] = float(fields[6].strip()) if fields[6].strip() else None
            result["data"]["reference_datum_code"] = fields[7].strip() if fields[7].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid DTM field: {str(e)}"
        
        return result