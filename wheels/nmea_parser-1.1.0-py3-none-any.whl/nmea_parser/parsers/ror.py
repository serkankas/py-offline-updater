from typing import Dict
from .base import BaseSentenceParser


class RORParser(BaseSentenceParser):
    @staticmethod
    def parse(data: str) -> Dict:
        result = {"error": {}, "data": {}}
        fields = data.split(',')
        
        if len(fields) != 3:
            result["error"]["message"] = f"ROR length mismatch: expected 3, got {len(fields)}"
            return result
        
        try:
            result["data"]["rudder_angle"] = float(fields[0].strip()) if fields[0].strip() else None
        except ValueError as e:
            result["error"]["message"] = f"Invalid ROR field: {str(e)}"
        
        return result