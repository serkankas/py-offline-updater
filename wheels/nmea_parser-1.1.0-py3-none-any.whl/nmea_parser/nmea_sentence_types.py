"""NMEA 0183 Sentence Type Constants"""

# Standard NMEA Sentences
HDT = "HDT"      # Heading - True
ZDA = "ZDA"      # Time and Date
GGA = "GGA"      # Global Positioning System Fix Data
GNS = "GNS"      # GNSS Fix Data
GLL = "GLL"      # Position Data
RMC = "RMC"      # Recommended Minimum Navigation Information
DTM = "DTM"      # Datum Reference
VBW = "VBW"      # Dual Ground/Water Speed
VHW = "VHW"      # Water Speed and Heading
VTG = "VTG"      # Course Over Ground and Ground Speed
THS = "THS"      # True Heading
HDG = "HDG"      # Heading - Magnetic
ROT = "ROT"      # Rate of Turn
DPT = "DPT"      # Depth of Water
MWV = "MWV"      # Wind Speed and Angle
MWD = "MWD"      # Wind Direction & Speed
VLW = "VLW"      # Distance Traveled through Water
HRM = "HRM"      # Heading/Roll/Pitch
PPLAR = "PPLAR"  # Proprietary - Roll and Pitch
HSS = "HSS"      # Hull Stress Sentence
ROR = "ROR"      # Rudder Order Request
HTC = "HTC"      # Heading/Track Control Command
HTD = "HTD"      # Heading/Track Control Data
RRS = "RRS"      # Rudder Sensor Angle
RSA = "RSA"      # Rudder Sensor Angle
PRC = "PRC"      # Propulsion Control Command
RPM = "RPM"      # Revolutions
TRC = "TRC"      # Thruster Control Command
TRD = "TRD"      # Thruster Response Data

# Grouped sentence types for easy filtering
POSITION_SENTENCES = {GGA, GNS, RMC, GLL}
TIME_SENTENCES = {ZDA}
HEADING_SENTENCES = {HDT, HDG, ROT, HRM, THS}
SPEED_SENTENCES = {VBW, VHW, VTG, MWV, MWD, VLW, RPM}
DEPTH_SENTENCES = {DPT}
NAVIGATION_SENTENCES = {DTM}
CONTROL_SENTENCES = {ROR, HTC, HTD, PRC, TRC}
SENSOR_SENTENCES = {RRS, RSA}
PROPULSION_SENTENCES = {RPM, TRC, TRD}
PROPRIETARY_SENTENCES = {PPLAR, HSS}

# All supported sentences
ALL_SENTENCES = {
    HDT, ZDA, GGA, GNS, GLL, RMC, DTM, VBW, VHW, VTG, THS, HDG, ROT, DPT,
    MWV, MWD, VLW, HRM, PPLAR, HSS, ROR, HTC, HTD, RRS, RSA, PRC, RPM, TRC, TRD
}