# exceptions.py

class BaseNmeaException(Exception):
    """Base exception for NMEA parser"""
    def __init__(self, message: str, sentence: str = None):
        self.message = message
        self.sentence = sentence
        super().__init__(self.format_message())
    
    def format_message(self) -> str:
        if self.sentence:
            return f"{self.message} | Sentence: {self.sentence}"
        return self.message


class InvalidCarriageReturn(BaseNmeaException):
    """Carriage return validation failed"""
    pass


class InvalidChecksum(BaseNmeaException):
    """Checksum validation failed"""
    pass


class InvalidNmeaSentence(BaseNmeaException):
    """Invalid NMEA sentence format"""
    pass


class InvalidSentenceStructure(BaseNmeaException):
    """Sentence structure is invalid"""
    pass

class InvalidNmeaType(BaseNmeaException):
    """Invalid type support"""
    pass
